import React from 'react';
import './LoginPage.css';
import { useNavigate } from 'react-router-dom';

function LoginPage() {
  const navigate = useNavigate();

  return (
    <div className="login-page">
      <div className="left-panel">
        <img
          src="/src/assets/imageLogo/Imagem_do_WhatsApp_de_2025-07-29_as_17.11.25_7b362e01-removebg-preview.png"
          alt="Logo Instituto Nossa Senhora de Fátima"
          className="login-logo"
        />
        <p className="login-quote">“Esforço que transforma, e o orgulho permanece.”</p>
      </div>
      <div className="right-panel">
        <button className="back-button" onClick={() => navigate('/')}>Voltar</button>
        <h2>Login</h2>
        <form className="login-form">
          <label htmlFor="email">Email ou nome:</label>
          <input type="text" id="email" name="email" placeholder="Email ou nome" />
          <label htmlFor="password">Senha:</label>
          <input type="password" id="password" name="password" placeholder="Senha" />
          <button type="submit" className="login-button">Logar</button>
        </form>
      </div>
    </div>
  );
}

export default LoginPage;
