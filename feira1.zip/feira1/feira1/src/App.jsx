import './App.css';
import Carousel from './Carousel';
import { useRef } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import LoginPage from './LoginPage';
import CadastroPage from './CadastroPage';

function Home() {
  const contactRef = useRef(null);
  const navigate = useNavigate();

  return (
    <div className="aplicativo">
      <header className="cabecalho">
        <div className="conteudo-cabecalho">
          <div className="container-logo">
            <img src="/src/assets/imageLogo/Imagem_do_WhatsApp_de_2025-07-29_as_17.11.25_7b362e01-removebg-preview.png" alt="Logo Instituto Nossa Senhora de Fátima" className="imagem-logo" />
          </div>
          <div className="container-logo2">
            <img src="/src/assets/imageLogo/Imagem_do_WhatsApp_de_2025-07-29_as_16.55.23_6805f037__1_-removebg-preview.png" alt="Logo Instituto Nossa Senhora de Fátima" className="imagem-logo2" />
          </div>
          <h1 className="texto-logo">Instituto Nossa Senhora de Fátima</h1>
          <nav className="navegacao">
            <button className="botao-nav" onClick={() => navigate('/cadastro')}>Cadastro</button>
            <button className="botao-nav" onClick={() => navigate('/login')}>Logar</button>
            <button className="botao-nav" onClick={() => contactRef.current.scrollIntoView({ behavior: 'smooth' })}>Sobre nós</button>
          </nav>
        </div>
      </header>
      <main className="conteudo-principal">
         <div className="secao-hero">
           <h1 className="titulo-principal">5° Feira de Profissões</h1>
           <Carousel />
         </div>
       </main>
      <section className="quadrados-imagem">
        <div className="container-quadrado">
          <div className="quadrado-imagem">
            <img src="/src/assets/imageSite/FEI_2024_CEDESP16.webp" alt="Imagem 1" />
          </div>
          <div className="quadrado-imagem">
            <img src="/src/assets/imageSite/FEI_2024_CEDESP85.webp" alt="Imagem 2" />
          </div>
        </div>
        <div className="container-quadrado">
          <div className="quadrado-imagem">
            <img src="/src/assets/imageSite/IMG_4844.webp" alt="Imagem 3" />
          </div>
          <div className="quadrado-imagem">
            <img src="/src/assets/imageSite/FEI_2024_CEDESP61.webp" alt="Imagem 4" />
          </div>
        </div>
      </section>
      <section className="secao-contato" ref={contactRef}>
        <h2>Contato</h2>
        <p>Sejam bem-vindos à ESCOLA do FREI</p>
        <p>
          O Instituto Nossa Senhora de Fátima, localizado no extremo sul de São Paulo, é uma instituição dedicada à formação de jovens de baixa renda, oferecendo oportunidades de educação e qualificação profissional. Com um compromisso firme de inclusão social, o instituto oferece vários cursos, capacitando seus alunos para o mercado de trabalho. Ao longo dos anos, o Instituto tem se destacado por seu impacto transformador na vida de jovens, promovendo não apenas conhecimento técnico, mas também habilidades comportamentais, sociais e tecnológicas essenciais para o sucesso profissional.
        </p>
        <p>Contato-nos:</p>
        <p>(11) 96938-6254</p>
        <p>institutonsfatima</p>
        <p>“Esforço que transforma, e o orgulho permanece.”</p>
      </section>
      <button className="voltar-ao-topo" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>Voltar ao topo</button>
      <div className="fundo-onda"></div>
    </div>
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/cadastro" element={<CadastroPage />} />
      </Routes>
    </Router>
  );
}

export default App;
