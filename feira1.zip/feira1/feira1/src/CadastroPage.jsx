import React from 'react';
import './CadastroPage.css';

function CadastroPage() {
  return (
    <div className="pagina-cadastro">
      <div className="container-formulario">
        <h2>Cadastro</h2>
        <form className="formulario-cadastro">
          <input type="text" placeholder="Nome completo:" />
          <input type="text" placeholder="CPF:" />
          <input type="text" placeholder="Nome do responsável:" />
          <input type="email" placeholder="Email:" />
          <input type="password" placeholder="Senha:" />
          <input type="text" placeholder="Escolaridade:" />
          <input type="tel" placeholder="Telefone:" />
          <input type="text" placeholder="Endereço:" />
          <label className="rotulo-negrito">Como ficou sabendo da feira?</label>
          <label className="rotulo-negrito">Já estudou no FREI?</label>
          <div className="grupo-radio">
            <button type="button" className="botao-radio">Sim</button>
            <button type="button" className="botao-radio">Não</button>
          </div>
          <button type="submit" className="botao-enviar">Enviar</button>
          <button type="button" className="botao-voltar" onClick={() => window.location.href = '/'}>Voltar</button>
        </form>
      </div>
    </div>
  );
}

export default CadastroPage;
