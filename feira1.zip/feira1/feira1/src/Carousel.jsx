import React, { useState } from 'react';
import './Carousel.css';

const Carousel = () => {
  const images = [
    '/src/assets/imageCarousel/FEI_2024_CEDESP15.jpeg',
    '/src/assets/imageCarousel/_MG_0398 editada.jpg',
    '/src/assets/imageCarousel/Cópia de Cópia de zFEI_2024_CEDESP89.jpeg',
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [transitionDirection, setTransitionDirection] = useState('');

  const nextImage = () => {
    setTransitionDirection('left');
    setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
  };

  const prevImage = () => {
    setTransitionDirection('right');
    setCurrentIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length);
  };

  const getImageIndex = (offset) => {
    return (currentIndex + offset + images.length) % images.length;
  };

  return (
    <div className="carrossel">
      <button className="seta-carrossel seta-carrossel-esquerda" onClick={prevImage}>
        &#8249;
      </button>

      <div className="container-imagens-carrossel">
        <div className="wrapper-imagem-carrossel wrapper-imagem-esquerda">
          <img
            src={images[getImageIndex(-1)]}
            alt={`Carrossel ${getImageIndex(-1)}`}
            className="imagem-carrossel imagem-carrossel-lado"
          />
        </div>

        <div className="wrapper-imagem-carrossel wrapper-imagem-centro">
          <img
            src={images[currentIndex]}
            alt={`Carrossel ${currentIndex}`}
            className="imagem-carrossel imagem-carrossel-ativa"
          />
        </div>

        <div className="wrapper-imagem-carrossel wrapper-imagem-direita">
          <img
            src={images[getImageIndex(1)]}
            alt={`Carrossel ${getImageIndex(1)}`}
            className="imagem-carrossel imagem-carrossel-lado"
          />
        </div>
      </div>

      <button className="seta-carrossel seta-carrossel-direita" onClick={nextImage}>
        &#8250;
      </button>
    </div>
  );
};

export default Carousel;
